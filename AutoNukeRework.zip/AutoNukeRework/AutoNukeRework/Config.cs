﻿using Exiled.API.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace AutoNukeRework
{
    public sealed class Config : IConfig
    {

        [Description("Wheter the plugin is Enabled or not.")]
        public bool IsEnabled { get; set; } = true;

        [Description("Whether or not debug messages should be shown in the console.")]
        public bool Debug { get; set; } = false;

        [Description("Time set for auto nuke to occur in minuts. Must be less than the original auto nuke time")]
        public float AutoNukeActivationTime { get; set; } = 20f;

        [Description("Color after autonuke start")]
        public Color AutoNukeColor { get; set; } = new Color(0.8f, 0.4f, 0f);

    }
}
