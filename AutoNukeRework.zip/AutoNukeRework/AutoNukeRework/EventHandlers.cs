﻿using Exiled.API.Enums;
using Exiled.API.Features;
using Exiled.API.Features.Doors;
using MEC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace AutoNukeRework
{
    public class EventHandlers
    {

        public void OnRoundStart()
        {
            Timing.CallDelayed((AutoNukeRework.Instance.Config.AutoNukeActivationTime * 60) - 120, CassieWarning);
        }
        public void CassieWarning()
        {
            if (Round.ElapsedTime.TotalSeconds >= ((AutoNukeRework.Instance.Config.AutoNukeActivationTime * 60) - 120) && Warhead.IsDetonated == false) 
            {
                Cassie.Message("Attention all Personnel. The facility Nuclear Reactors are .g2 Unstable. Nuclear reactor core temperature estimated at .g3 3000 Degrees Celsius. Repairs needed immediately", isNoisy: true, isSubtitles: true);
                Timing.CallDelayed(60, OnCassieWarning2);
            }
        }

        public void OnCassieWarning2()
        {
            if (Round.ElapsedTime.TotalSeconds >= ((AutoNukeRework.Instance.Config.AutoNukeActivationTime * 60) - 60) && Warhead.IsDetonated == false) 
            {
                Cassie.Message("Pitch_0.75 .g4 .g4 .g4 Danger. Pitch_1 The facility Nuclear Reactors are overheating .g1.  Estimated explosion time is 3 .g3 minutes. Please, evacuate immediately", isNoisy: true, isSubtitles: true);
                Warhead.IsLocked = true;
                Timing.CallDelayed(60, CassieWarning3);
            }
        }

        public void CassieWarning3()
        {
            if (Round.ElapsedTime.TotalSeconds >= (AutoNukeRework.Instance.Config.AutoNukeActivationTime * 60) && Warhead.IsDetonated == false)
            {
                Timing.CallDelayed(132, () =>
                {
                    if (Round.ElapsedTime.TotalSeconds >= (AutoNukeRework.Instance.Config.AutoNukeActivationTime * 60) && Warhead.IsDetonated == false)
                    {
                        Warhead.Detonate();
                    }
                });

                Timing.CallDelayed(36, () =>
                {
                    if (Round.ElapsedTime.TotalSeconds >= (AutoNukeRework.Instance.Config.AutoNukeActivationTime * 60) && Warhead.IsDetonated == false)
                    {
                        Map.ChangeLightsColor(AutoNukeRework.Instance.Config.AutoNukeColor);
                        Warhead.TriggerDoors(true);
                        Door elevatornuke = Door.Get(DoorType.ElevatorNuke);
                        elevatornuke.ChangeLock(DoorLockType.Warhead);
                    }
                });
                Cassie.Message("pitch_0.3 .g4 .g4 Pitch_1 DANGER . Pitch_0.75 DANGER . Pitch_0.50 DANGER . Pitch_1 Estimated explosion time is 2 .g4 minutes . All Personnel are required to evacuate as far as possible from the Facility . Every anomaly and biological thing inside of site 0 .g3 2 will be terminated . Activating .g6 emergency detonation protocol .g5", isNoisy: true, isSubtitles: true);
                Cassie.Message(". jam_4_9 pitch_0.1 .g4 .g4 pitch_0.2 .g1 pitch_0.1 .g4 pitch_0.2 .g1 pitch_0.1 .g4 pitch_0.2 .g1 pitch_0.1 .g4 pitch_0.2 .g1 pitch_0.1 .g4 pitch_0.2 .g1 pitch_0.1 .g4 pitch_0.2 .g1 pitch_0.1 .g4 pitch_0.2 .g1 pitch_0.1 .g4 pitch_0.2 .g1 pitch_0.1 .g4 pitch_0.2 .g1 pitch_0.1 .g4 pitch_0.2 .g1 pitch_0.1 .g4 pitch_0.2 .g1 pitch_0.1 .g4 pitch_0.2 .g1 pitch_0.1 .g4 pitch_0.2 .g1 pitch_0.1 .g4 pitch_0.2 .g1 pitch_0.1 .g4 pitch_0.2 .g1 pitch_0.1 .g4 pitch_0.2 .g1 pitch_0.1 .g4 pitch_0.2 .g1 pitch_0.1 .g4 pitch_0.2 .g1 pitch_0.09 .g4 pitch_0.2 .g1 pitch_0.09 .g4 pitch_0.2 .g1 pitch_0.09 .g4 .g4 .g4 .g4");
            }
        }

        public void OnWarheadDetonate()
        {
            Timing.CallDelayed(3, () =>
            {
                Cassie.Message("pitch_0.03 .g7 pitch_0.03 .g7 pitch_0.03 .g7 pitch_0.03 .g7 pitch_0.03 .g7 pitch_0.03 .g7 pitch_0.03 .g7");
            });
        }

    }
}
