﻿using System;
using AutoNukeRework;
using Exiled.API.Enums;
using Exiled.API.Features;
using Player = Exiled.Events.Handlers.Player;
using Server = Exiled.Events.Handlers.Server;
using Nuke = Exiled.Events.Handlers.Warhead;
using Exiled.Events.EventArgs.Player;

namespace AutoNukeRework
{
    public class AutoNukeRework : Plugin<Config>
    {
        public static AutoNukeRework Instance { get; private set; }
        public override string Name => "AutoNukeRework";
        public override string Author => "Admiro && Black-Cat";
        public override string Prefix => "AutoNukeRework";
        public override Version Version => new Version(1, 0, 0);
        public override Version RequiredExiledVersion => new Version(8, 7, 0);
        public override PluginPriority Priority => PluginPriority.Medium;
        private EventHandlers player;
        private EventHandlers server;

        public override void OnEnabled()
        {
            Instance = this;
            RegisterEvents();
            base.OnEnabled();
        }
        public override void OnDisabled()
        {
            UnRegisterEvents();
            base.OnDisabled();
        }

        public void RegisterEvents()
        {
            player = new EventHandlers();
            server = new EventHandlers();

            Nuke.Detonated += server.OnWarheadDetonate;
            Server.RoundStarted += server.OnRoundStart;
        }
        public void UnRegisterEvents()
        {
            Nuke.Detonated -= server.OnWarheadDetonate;
            Server.RoundStarted -= server.OnRoundStart;

            player = null;
            server = null;
        }
    }
}
